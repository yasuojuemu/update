<?php
/**
 * 别名 常量定义文件
 * 路径文件皆为物理地址

 */
$baseDir = dirname(__FILE__);
$uploads = $baseDir.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'..';
define('UPLOAD_PATH', $uploads.'/uploads');
define('UPLOAD_PATH_TMP', $uploads.'/uploads_tmp');

define('STATICS','/statics');		//网站静态文件路径 css js images  
