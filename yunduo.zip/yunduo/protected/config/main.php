﻿<?php

//配置文件(后台)
require_once(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'alias.php'); //加载别名文件
require_once(dirname(__FILE__) . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . DIRECTORY_SEPARATOR . 'libs' . DIRECTORY_SEPARATOR . 'function' . DIRECTORY_SEPARATOR . 'global.func.php'); //加载全局函数

return array(
    'basePath' => dirname(__FILE__) . DIRECTORY_SEPARATOR . '..',
    'name' => 'weixin',
    'defaultController' => 'site/index',  //默认控制器
    // preloading 'log' component
    'preload' => array('log'),

    // autoloading model and component classes
    'import' => array(
        'application.models.*',
        'application.libs.base.*',
		'application.libs.tools.*',
        //'ext.PHPExcel.PHPExcel',                //excel报表


    ),


    // application components
    'components' => array(
        'db' => array(
            'class' => 'CDbConnection',
            'connectionString' => 'mysql:host=127.0.0.1;dbname=yunduo',//@todo
            'emulatePrepare' => true,
            'username' => 'root',//@todo
            'password' => 'root',//@todo
            'charset' => 'utf8',
            'tablePrefix' => 'w_'
        ),

        

        'errorHandler' => array(
            // use 'site/error' action to display errors
            'errorAction' => 'site/error',
        ),
    ),
);