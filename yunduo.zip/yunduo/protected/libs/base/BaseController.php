<?php

class BaseController extends CController
{

    //后台登录操作
    public function Login($ProName = '')
    {
        //如果登录了，直接跳转
//        if($this->checkLogin()) $this->showMessage('你已经登录',U('new/list'));
        if (isset(Yii::app()->session['admin']) && Yii::app()->session['admin']['username'] == "$ProName")
            $this->showMessage('你已经登录', U("$ProName/list"));
        if (!empty($_POST) && Yii::app()->request->isAjaxRequest) {
            $params['username'] = $_POST['username'];
            $params['password'] = $_POST['password'];
            $params['password'] = Tools::setpwd($_POST['password']);
            $model = new Admin();
            $criteria = new CDbCriteria;
            $criteria->select = '*';
            $criteria->condition = 'username=:username';//查询条件
            $criteria->params = array(':username' => $params['username']);
            $rs = $model->find($criteria);
            if ($rs) {
                if ($rs['password'] != $params['password']) $this->showBox('密码错误', '', '0');
                $rs = json_decode(CJSON::encode($rs), TRUE);//因为是对象无法输出，需要转为数组
                unset($rs['password']);//把用户信息保存在SESSION里
                Yii::app()->session['admin'] = $rs;
                $this->showBox('正在登录', U("$ProName/list"), '1');
            } else {
                $this->showBox('用户不存在', '', '0');
            }
        }
        $this->render('/login/index', ['loginUrl' => U("$ProName/login")]);
    }

    //检查后台是否登陆
    public function checkLogin()
    {
        if (isset(Yii::app()->session['admin'])) return true;
        return false;
    }

    //提示页面
    function showMessage($content = 'this`s tips', $url = '', $time = 1550)
    {
        if (is_array($content)) {
            $re = array(
                'content' => $content['content'],
                'url' => $content['url'],
                'time' => $content['time']
            );
        } else {
            $re = array(
                'content' => $content,
                'url' => $url,
                'time' => $time
            );
        }
        $isAjax = Yii::app()->request->getIsAjaxRequest();
        $this->renderPartial('//show_message', array('msg' => $re, 'isAjax' => $isAjax));
        Yii::app()->end();
    }

    //异步信息
    function showBox($content, $url = '', $type = 1, $time = 1550, $callback = '')
    {
        if (is_array($content)) {
            $re = array(
                'content' => $content['content'],
                'url' => $content['url'] == '' ? false : $content['url'],
                'type' => $content['type'],
                'time' => $content['time'],
                'callback' => $content['callback']
            );
        } else {
            $re = array(
                'content' => $content,
                'url' => $url == '' ? false : $url,
                'type' => $type,
                'time' => $time,
                'callback' => $callback
            );
        }
        echo json_encode($re);
        Yii::app()->end();
    }

    //return json or jsonp
    public function returnJson($rs, $cb = '')
    {
        if ($cb !== '') {
            echo $cb . '(' . json_encode($rs) . ')';
        } else {
            echo json_encode($rs);
        }
//        exit;
        Yii::app()->end();
    }

}