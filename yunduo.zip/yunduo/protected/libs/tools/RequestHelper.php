<?php

//namespace common\helpers;

class RequestHelper extends BaseRequestHelps
{
    public function init() {}
}
