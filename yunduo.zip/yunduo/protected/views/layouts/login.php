<?php
/**
 * Created for moneplus.
 * User: tonghe.wei@moneplus.cn
 * Date: 2017/1/6
 * Time: 15:46
 */
 ?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title><?= $this->title ?></title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no">
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="alternate icon" type="image/png" href="<?php echo STATICS?>/admin/i/favicon.png">
    <link rel="stylesheet" href="<?php echo STATICS?>/admin/css/amazeui.min.css"/>
    <!--[if lt IE 9]>
    <script src="http://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
    <script src="http://cdn.staticfile.org/modernizr/2.8.3/modernizr.js"></script>
    <script src="<?= STATICS ?>/admin/js/amazeui.ie8polyfill.min.js"></script>
    <![endif]-->
    <!--[if (gte IE 9)|!(IE)]><!-->
    <script src="<?= STATICS ?>/admin/js/jquery.min.js"></script>
    <!--<![endif]-->
    <script src="<?= STATICS ?>/admin/js/amazeui.min.js"></script>
    <script src="<?= STATICS ?>/admin/js/app.js"></script>

    <link rel="icon" type="image/png" href="<?= STATICS ?>/admin/i/favicon.png">
    <link rel="apple-touch-icon-precomposed" href="<?= STATICS ?>/admin/i/app-icon72x72@2x.png">
    <meta name="apple-mobile-web-app-title" content="Amaze UI" />
    <link rel="stylesheet" href="<?= STATICS ?>/admin/css/amazeui.min.css"/>
    <link rel="stylesheet" href="<?= STATICS ?>/admin/css/admin.css">
    <style>
        .header {
            text-align: center;
        }
        .header h1 {
            font-size: 200%;
            color: #333;
            margin-top: 30px;
        }
        .header p {
            font-size: 14px;
        }
    </style>
</head>
<body>
<div class="header">
    <div class="am-g">
        <h1><?= $this->name ?></h1>
<!--        <p>Integrated Development Environment<br/>代码编辑，代码生成，界面设计，调试，编译</p>-->
    </div>
    <hr />
</div>
<?= $content?>

</body>
</html>

