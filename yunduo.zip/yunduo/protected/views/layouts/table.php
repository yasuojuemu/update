<?php
/**
 * Created for moneplus.
 * User: tonghe.wei@moneplus.cn
 * Date: 2017/1/9
 * Time: 17:49
 */
?>
<!doctype html>
<html class="no-js">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?=$this->title?>后台管理</title>
    <meta name="description" content="这是一个 table 页面">
    <meta name="keywords" content="table">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="icon" type="image/png" href="<?= STATICS ?>/admin/i/favicon.png">
    <link rel="apple-touch-icon-precomposed" href="<?= STATICS ?>/admin/i/app-icon72x72@2x.png">
    <meta name="apple-mobile-web-app-title" content="Amaze UI" />

    <!--upload-->
    <link rel="stylesheet" href="<?= STATICS ?>/admin/upload/cropper.css">
    <link rel="stylesheet" type="text/css" href="<?= STATICS ?>/admin/upload/style.css">
    <!--uploads-->
    <link rel="stylesheet" type="text/css" href="<?= STATICS ?>/admin/uploads/style.css" />

    <link rel="stylesheet" href="<?= STATICS ?>/admin/css/amazeui.min.css"/>
    <link rel="stylesheet" href="<?= STATICS ?>/admin/css/admin.css">


    <!--[if lt IE 9]>
    <script src="http://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
    <script src="http://cdn.staticfile.org/modernizr/2.8.3/modernizr.js"></script>

    <script src="<?= STATICS ?>/admin/js/amazeui.ie8polyfill.min.js"></script>
    <![endif]-->

    <!--[if (gte IE 9)|!(IE)]><!-->
    <script src="<?= STATICS ?>/admin/js/jquery.min.js"></script>
    <!--<![endif]-->
    <script src="<?= STATICS ?>/admin/js/amazeui.min.js"></script>
    <script src="<?= STATICS ?>/admin/js/app.js"></script>
</head>
<body>
<!--[if lte IE 9]>
    <p class="browsehappy">
        你正在使用<strong>过时</strong>的浏览器，Amaze UI 暂不支持。 请
        <a href="http://browsehappy.com/" target="_blank">升级浏览器</a>
        以获得更好的体验！
    </p>
<![endif]-->

<header class="am-topbar am-topbar-inverse admin-header">
    <div class="am-topbar-brand">
        <strong><?=$this->name?></strong> <small>后台管理</small>
    </div>

    <button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-success am-show-sm-only" data-am-collapse="{target: '#topbar-collapse'}">
        <span class="am-sr-only">导航切换</span>
        <span class="am-icon-bars"></span>
    </button>

    <div class="am-collapse am-topbar-collapse" id="topbar-collapse">

        <ul class="am-nav am-nav-pills am-topbar-nav am-topbar-right admin-header-list">
<!--            <li><a href="javascript:;"><span class="am-icon-envelope-o"></span> 收件箱 <span class="am-badge am-badge-warning">5</span></a></li>-->
            <li class="am-dropdown" data-am-dropdown>
                <a class="am-dropdown-toggle" data-am-dropdown-toggle href="javascript:;">
                    <span class="am-icon-users"></span>
                    欢迎你，<?= Yii::app()->session['admin']['name']?>
                    <span class="am-icon-caret-down"></span>
                </a>
                <ul class="am-dropdown-content">
<!--                    <li><a href="#"><span class="am-icon-user"></span> 资料</a></li>-->
<!--                    <li><a href="#"><span class="am-icon-cog"></span> 设置</a></li>-->
                    <li><a href="#" class="loginout"><span class="am-icon-power-off"></span> 退出</a></li>
                </ul>
            </li>
<!--            <li class="am-hide-sm-only"><a href="javascript:;" id="admin-fullscreen"><span class="am-icon-arrows-alt"></span> <span class="admin-fullText">开启全屏</span></a></li>-->
        </ul>
    </div>
</header>

<div class="am-cf admin-main">
    <!-- sidebar start -->

    <!-- sidebar end -->

    <!-- content start -->
    <?= $content ?>
    <!-- content end -->

    <div class="am-modal am-modal-no-btn" tabindex="-1" id="your-modal">
        <div class="am-modal-dialog">
            <div class="am-modal-hd">微信头像
                <a href="javascript: void(0)" class="am-close am-close-spin" data-am-modal-close>&times;</a>
            </div>
            <div class="am-modal-bd">
                Modal 内容。
            </div>
        </div>
    </div>
</div>

<a href="#" class="am-icon-btn am-icon-th-list am-show-sm-only admin-menu" data-am-offcanvas="{target: '#admin-offcanvas'}"></a>

<footer>
    <hr>
    <p class="am-padding-left"><?= date('Y') ?></p>
</footer>

<script>
    $(document).on('click', '.loginout', function(){
        if(confirm('您确定要退出吗？')){
            window.location.href = '<?php echo U("$this->ProName/loginout")?>';
        }else{
            return false;
        }
    })

    //图片放大缩小
    $(document).on('click', '.ReSizeImgNew', function(){
        var s = $(this).attr('src');
        $(".am-modal-bd").html('<img width="500px" height="500px" src="'+s+'"/>');
        $('#your-modal').modal('toggle');
    })
</script>
</body>
</html>

