<?php
/**
 * Created for moneplus.
 * User: tonghe.wei@moneplus.cn
 * Date: 2017/1/6
 * Time: 15:59
 */
 ?>
<div class="am-g">
    <div class="am-u-lg-6 am-u-md-8 am-u-sm-centered">
        <h3>登录</h3>
        <hr>
        <!--        <div class="am-btn-group">-->
        <!--            <a href="#" class="am-btn am-btn-secondary am-btn-sm"><i class="am-icon-github am-icon-sm"></i> Github</a>-->
        <!--            <a href="#" class="am-btn am-btn-success am-btn-sm"><i class="am-icon-google-plus-square am-icon-sm"></i> Google+</a>-->
        <!--            <a href="#" class="am-btn am-btn-primary am-btn-sm"><i class="am-icon-stack-overflow am-icon-sm"></i> stackOverflow</a>-->
        <!--        </div>-->
        <!--        <br>-->
        <!--        <br>-->

        <form method="post" class="am-form">
            <label for="text">账号:</label>
            <input type="text" name="" id="text" value=""/>
            <br/>
            <label for="password">密码:</label>
            <input type="password" name="" id="password" value=""/>
            <br/>
            <label for="remember-me" id="tip">
<!--                <input id="remember-me" type="checkbox">-->
<!--                记住密码-->
            </label>
            <br/>
            <div class="am-cf">
                <input type="button" name="" id="login" value="登 录" class="am-btn am-btn-primary am-btn-sm am-fl"/>
                <!--                <input type="submit" name="" value="忘记密码 ^_^? " class="am-btn am-btn-default am-btn-sm am-fr">-->
            </div>
        </form>
        <hr>
        <p><?= date('Y')?></p>
    </div>
</div>

<script>

    $(function(){
        //回车提交
        document.onkeydown = function(e){
            if(!e) e = window.event;//火狐中是 window.event
            if((e.keyCode || e.which) == 13){
                document.getElementById("login").click();
            }
        };
    });

    $(document).on('click', '#login', function(){
        var username = $("#text").val();
        var password = $("#password").val();
        var vcod = $("#vcod").val();
        $.ajax({
            type: "POST",
            url: "<?= $loginUrl ?>",
            data: "username="+username+"&password="+password+"&vcod="+vcod,
            dataType:"json",
            success: function(msg){
                $("#tip").html(msg.content);
                if(msg.type ==1){window.location.href=msg.url};
            }
        });
    });

</script>
