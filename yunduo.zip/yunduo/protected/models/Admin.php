<?php
//后台管理员

class Admin extends CActiveRecord{
	public $id;//主键
	public $username;//用户名
	public $name;//姓名
	public $password;//密码
	public $email;//邮箱
	public $status;//状态
	public $lastlogintime;//最后一次登录的时间
	public $lastloginip;//最后一次登录的IP
	

	
	//Model静态方法为必须有的方法
	public static function model($className=__CLASS__){
		return parent::model($className);
	}
	
	//tableName方法也是必须有的方法
	public function tableName(){
		return '{{admin}}';
	}
	public function  primaryKey(){
		return 'id';
	}

	public function rules()
	{
		return array(
				array('id,username,name,password,email,status,lastlogintime,lastloginip','safe'),
		);
	}
	
}