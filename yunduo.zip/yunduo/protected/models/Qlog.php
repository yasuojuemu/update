<?php
/**
 * Created for ttt.
 * User: ttt
 * Date: 2017/9/11
 * Time: 11:46
 */
class Qlog extends Base
{
    public static function model($className=__CLASS__)
    {
        return parent::model($className);
    }

    public function tableName()
    {
        return '{{yd_qlog}}';
    }

    public function  primaryKey()
    {
        return 'id';
    }
}