<?php
/**
 * Created for moneplus.
 * User: tonghe.wei@moneplus.cn
 * Date: 2017/1/9
 * Time: 14:51
 */
 class Base extends CActiveRecord
{


     /**
      * 简介：
      * @author  tonghe.wei@moneplus.cn
      * @param string  $field     字段
      * @param array   $params    条件
      * @param string  $likeK     like条件  key
      * @param string  $likeV     like条件  value
      * @param array   $page      分页
      * @param string  $order     排序
      * @param boolean $isCount   是否返回count
      * @return array|count
      */
     public function Sel($field='*',$params=[],$likeK='',$likeV='',$page=[],$order='',$isCount=false)
     {
         $criteria = new CDbCriteria;
         $criteria->select = $field;

         if(isset($params['start']) && isset($params['end'])){//时间条件
             $criteria->condition = ' addtime>:start and addtime<:end ';
             $criteria->params = array(':start'=>$params['start'],':end'=>$params['end']+60*60*24);
         }
         unset($params['start']); unset($params['end']);

         if($params){
             $params = self::comParams2($params);
             $criteria->condition = $criteria->condition?$criteria->condition.' and '.$params['con']:$params['con'];
             if($criteria->params){
                 foreach ( $params['par'] as $k=>$v){
                     $criteria->params[$k] = $v;
                 }
             }else{
                 $criteria->params = $params['par'];
             }
         }

         if(!empty($likeK)&&!empty($criteria->condition)){//like 条件
             $criteria->condition .= " and $likeK like '%$likeV%' ";
         }elseif(!empty($likeK)){
             $criteria->condition = " $likeK like '%$likeV%' ";
         }
         if(!empty($page)){//page
             $offset = ($page['page']-1)*$page['pageSize'];
             $criteria->limit = $page['pageSize'];
             $criteria->offset = $offset;
         }
         if(!empty($order)){//order
             $criteria->order = $order;
         }else{
             $criteria->order = 'addtime DESC';
         }
//         echo '<pre>';print_r($criteria);echo '</pre>';exit;
         if($isCount) return $this->count($criteria);
         $rs = $this->findAll($criteria);
         return json_decode(CJSON::encode($rs),TRUE);//因为是对象无法输出，需要转为数组
     }
     //查询一条记录
     public function Findone($zdname,$zdval){
         $oneInfo = $this->find($zdname.'=:'.$zdname,array(':'.$zdname=>$zdval));
         return json_decode(CJSON::encode($oneInfo),TRUE);//因为是对象无法输出，需要转为数组
     }


     /**
      * 简介：
      * @author  tonghe.wei@moneplus.cn
      * @param array   $params    条件
      * @param string  $likeK     like条件  key
      * @param string  $likeV     like条件  value
      * @return count
      */
     public function SelCount($params=[],$likeK='',$likeV='')
     {
         $criteria = new CDbCriteria;
         $criteria->select = '*';

         if(isset($params['start']) && isset($params['end'])){//时间条件
             $criteria->condition = ' addtime>:start and addtime<:end ';
             $criteria->params = array(':start'=>$params['start'],':end'=>$params['end']+60*60*24);
         }
         unset($params['start']); unset($params['end']);

         if($params){
             $params = self::comParams2($params);
             $criteria->condition = $criteria->condition?$criteria->condition.' and '.$params['con']:$params['con'];
             if($criteria->params){
                 foreach ( $params['par'] as $k=>$v){
                     $criteria->params[$k] = $v;
                 }
             }else{
                 $criteria->params = $params['par'];
             }
         }
         
         if(!empty($likeK)&&!empty($criteria->condition)){//like 条件
             $criteria->condition .= " and $likeK like '%$likeV%' ";
         }elseif(!empty($likeK)){
             $criteria->condition = " $likeK like '%$likeV%' ";
         }
         return $this->count($criteria);
     }

     public function Add($params=[])
     {
         $this->setAttributes($params, false);
//         $this->attributes = $params;
         return $this->save();
     }

     public function AddReturnId($params=[])
     {
         $this->setAttributes($params, false);
//         $this->attributes = $params;
         $this->save();
         return $this->attributes['id'];
     }

     public function Del($params=[])
     {
         $params = self::comParams2($params);
         $criteria=new CDbCriteria;
         $criteria->condition = $params['con'];
         $criteria->params = $params['par'];
         return $this::model()->deleteAll($criteria);
     }

     public function Up($params=[], $condition=[])
     {
         $condition = self::comParams2($condition);
         return $this::model()->updateAll($params, $condition['con'], $condition['par']);
     }

     //组合字段
     public static function comParams($params=array(),$condition='and',$nub="-4")
     {
         $param = '';
         foreach($params as $k=>$v){
             $param .="$k='$v' $condition ";
         }
         $param =substr($param,0,$nub);
         return $param;
     }

     //组合字段
     public static function comParams2($params = [])
     {
         $con = '';
         $par = [];
         foreach($params as $k=>$v){
             $con.=$k."=:".$k." and ";
             $par[":".$k]=$v;
         }
         $con =substr($con,0,-5);
         return ['con'=>$con, 'par'=>$par];
     }
}