<?php
/**
 * Created for ttt.
 * User: ttt
 * Date: 2017/9/11
 * Time: 11:46
 */
class Jdcc extends Base
{
    public static function model($className=__CLASS__)
    {
        return parent::model($className);
    }

    public function tableName()
    {
        return '{{yd_jdcc}}';
    }

    public function  primaryKey()
    {
        return 'id';
    }
}